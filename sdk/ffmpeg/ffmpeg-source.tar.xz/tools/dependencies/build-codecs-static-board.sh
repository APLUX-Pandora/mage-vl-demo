#!/bin/bash
set -euo pipefail

if [ "$#" -gt 2 ]; then
  echo "Usage: $0 [FFMPEG_SOURCE_ROOT [pixel|bitcost]]" >&2
  exit 2
fi

root=$(pwd -P)
recipe_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
patch_dir="$recipe_dir/../../third_party/ffmpeg/patches"
profiles=(pixel bitcost)
if [ "$#" -ge 1 ]; then
  source_root=$(realpath "$1")
  test "$(cat "$source_root/RELEASE")" = 5.1
  case "${2:-}" in
    pixel) profiles=(pixel development) ;;
    bitcost) profiles=(bitcost) ;;
    "") profiles+=(development) ;;
    *) echo "Unknown FFmpeg profile: $2" >&2; exit 2 ;;
  esac
else
  snapshot="$root/codec-video-prep/ffmpeg/ffmpeg-snapshot.tar.bz2"
  printf '%s  %s\n' 32b56fb01ce90d452958ae25e91c9564abf49ed5453c127bec23c63e530aa8fa "$snapshot" | sha256sum -c -
fi

copy_source() {
  local build=$1
  if [ -z "${source_root:-}" ]; then
    tar -xjf "$snapshot" -C "$build" --strip-components=1
  elif [ -e "$source_root/.git" ]; then
    git -C "$source_root" archive HEAD | tar -xf - -C "$build"
  else
    case "$build/" in
      "$source_root/"*) echo "Build outside the extracted source tree" >&2; return 2 ;;
    esac
    cp -a "$source_root/." "$build/"
  fi
}

for kind in "${profiles[@]}"; do
  build="$root/ffmpeg-$kind-static-source"
  prefix="$root/ffmpeg-$kind-static"
  test ! -e "$prefix"
  mkdir "$build"
  copy_source "$build"

  options=(
    --prefix=/usr --disable-shared --enable-static --enable-pic
    --disable-programs --disable-doc --disable-debug --disable-autodetect
    --disable-everything --enable-avcodec --enable-avformat --enable-avutil
  )
  if [ "$kind" = development ]; then
    options+=(
      --disable-avdevice --disable-avfilter --disable-postproc
      --disable-swresample --disable-network
      --enable-swscale --enable-protocol=file --enable-demuxer=mov
      --enable-parser=h264 --enable-decoder=h264
      '--extra-cflags=-fstack-protector-strong -fstack-clash-protection -U_FORTIFY_SOURCE -D_FORTIFY_SOURCE=2 -Wformat=2 -Werror=format-security -ffp-contract=off'
    )
  else
    patch --batch --forward --fuzz=0 -p1 -d "$build" < "$patch_dir/$kind.patch"
    options+=(
      --enable-swresample --enable-swscale --enable-protocol=file
      --enable-demuxer=mov --enable-demuxer=h264 --enable-parser=h264 --enable-decoder=h264
    )
  fi

  (
    cd "$build"
    ./configure "${options[@]}" > configure.log 2>&1 || { tail -60 configure.log; exit 1; }
    make -j"${FFMPEG_BUILD_JOBS:-2}" > build.log 2>&1 || { tail -60 build.log; exit 1; }
    make install DESTDIR="$build/install" > install.log 2>&1
    mv "$build/install/usr" "$prefix"
  )
  printf 'Built %s FFmpeg %s\n' "$kind" "$(cat "$build/RELEASE")"
  sha256sum "$prefix"/lib/*.a
done

if [ -n "${source_root:-}" ]; then
  python3 "$recipe_dir/namespace_codec_archives.py" "$root" ${2:+"$2"}
fi
