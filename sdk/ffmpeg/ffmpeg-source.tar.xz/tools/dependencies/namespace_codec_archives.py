"""Keep the pixel and bitcost FFmpeg globals separate in one shared library.

The generated archives are inputs for relinking the SDK.
"""
import argparse,hashlib,json,re,subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('dependencies', type=Path)
parser.add_argument('profile', nargs='?', choices=('pixel', 'bitcost'))
args = parser.parse_args()
profiles = (args.profile,) if args.profile else ('pixel', 'bitcost')
root=args.dependencies.resolve();output=root/'codec-static-namespaced'
assert not output.exists(),'fresh namespace output required'
output.mkdir();records=[]
for kind in profiles:
    inputs=[root/f'ffmpeg-{kind}-static/lib/lib{name}.a' for name in ('avcodec','avutil','swscale')]
    symbols=set()
    for archive in inputs:
        listing=subprocess.check_output(['nm','-g','--defined-only',str(archive)],text=True)
        for line in listing.splitlines():
            parts=line.split()
            if len(parts)==3 and re.fullmatch('[A-Za-z_][A-Za-z0-9_.$]*',parts[2]) and re.fullmatch('[A-Za-z]',parts[1]):
                symbols.add(parts[2])
    prefix=f'mage_{kind}_'
    mapping=output/f'{kind}-symbols.map'
    mapping.write_text(''.join(f'{name} {prefix}{name}\n' for name in sorted(symbols)))
    for archive in inputs:
        destination=output/f'libmage_{kind}_{archive.stem[3:]}.a'
        subprocess.run(['objcopy',f'--redefine-syms={mapping}',str(archive),str(destination)],check=True)
        records.append({'kind':kind,'source':str(archive),'source_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'path':str(destination),'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'map_sha256':hashlib.sha256(mapping.read_bytes()).hexdigest(),'renamed_defined_symbols':len(symbols)})
(output/'manifest.json').write_text(json.dumps({'status':'static inputs only; no SDK/inference qualification','archives':records},indent=2)+'\n')
print('PREPARED_NAMESPACED_CODEC_ARCHIVES',json.dumps(records))
