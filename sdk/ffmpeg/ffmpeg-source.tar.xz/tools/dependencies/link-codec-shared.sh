#!/bin/bash
# Link only PIC FFmpeg objects. The SDK loads this DSO from its own directory.
set -euo pipefail

if [ "$#" -ne 4 ] || [[ "$2" != pixel && "$2" != bitcost ]]; then
  echo "Usage: $0 CC pixel|bitcost NAMESPACED_ARCHIVE_DIR OUTPUT_FILE" >&2
  exit 2
fi

cc=$1
profile=$2
archives=$3
output=$4
recipe_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
abi="$recipe_dir/../../include/mage_ffmpeg.h"
symbols=$(sed -nE "s/^.*(mage_${profile}_[[:alnum:]_]+)\(.*/\1;/p" "$abi")
test -n "$symbols"
map=$(mktemp)
trap 'rm -f -- "$map"' EXIT
printf '{ global:\n%s\nlocal: *; };\n' "$symbols" > "$map"

"$cc" -shared -Wl,--no-undefined,-z,relro,-z,now,-z,noexecstack,-z,text,-z,separate-code \
  -Wl,--build-id=sha1 -Wl,--version-script,"$map" \
  -Wl,-soname,"libmage_ffmpeg_$profile.so" -o "$output" \
  -Wl,--whole-archive \
  "$archives/libmage_${profile}_avcodec.a" \
  "$archives/libmage_${profile}_avutil.a" \
  "$archives/libmage_${profile}_swscale.a" \
  -Wl,--no-whole-archive -pthread -lm
